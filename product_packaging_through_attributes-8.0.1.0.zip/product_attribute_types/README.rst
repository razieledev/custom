Product attribute types
=======================

This module extends product attributes, adds new type range, also the option of
defining if it is required and a default value for the attribute.


Credits
=======

Contributors
------------
* Mikel Arregi <mikelarregi@avanzosc.es>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciobaeza.com>
* Ana Juaristi <ajuaristio@gmail.com>
