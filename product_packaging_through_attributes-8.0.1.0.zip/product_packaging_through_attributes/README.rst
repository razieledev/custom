Product Packaging through Attributes
====================================

This module allows to define an attribute as "is package" to define a
(package) product and automatically assign it to the product.
